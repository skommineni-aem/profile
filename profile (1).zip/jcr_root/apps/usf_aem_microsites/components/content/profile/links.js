
"use strict";
use(function(){

    return{
linksRes:resource.getChild("secondaryLinks")
};
});

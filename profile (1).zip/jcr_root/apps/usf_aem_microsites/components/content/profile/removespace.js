"use strict";
use(function(){
var title = this.title;
    return{
    title:title.replace(" ","").toLowerCase()
    };
});